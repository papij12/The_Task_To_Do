package com.tasktodo;


import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.widget.TabHost;

// Adding database entities
@Database(entities = {MainTask.class},version = 1,exportSchema = false)
public abstract class ThetasksDB extends RoomDatabase {
    //Create database instance

    private static ThetasksDB database;

    //Define database name

    private static String DATABASE_NAME = "database";

    public synchronized static ThetasksDB getInstance(Context context){
        //Check condition
     if (database == null){
         //When database is empty
         // Initialize database

         database = Room.databaseBuilder(context.getApplicationContext()
                 ,ThetasksDB.class,DATABASE_NAME)
                 .allowMainThreadQueries()
                 .fallbackToDestructiveMigration()
                 .build();
     }
     //Return database
        return database;

    }

    //Create Dao
    public abstract MainDao mainDao();

}


